// server.js
require("dotenv").config();

const http = require("http");
const { Server } = require("socket.io");

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const crypto = require("crypto");
const {
  Connection,
  PublicKey,
  VersionedTransaction,
  TransactionMessage,
  SystemProgram,
  ComputeBudgetProgram,
} = require("@solana/web3.js");

// ---- Dice/shared helpers (same as before) ----
const { deriveVaultPda, deriveAdminPda, buildEd25519VerifyIx } = require("./solana");
const { roll1to100 } = require("./rng");
const { ADMIN_PK, buildMessageBytes, signMessageEd25519 } = require("./signer");

// ---- Cluster / Programs ----
const CLUSTER = process.env.CLUSTER || "https://api.devnet.solana.com";

// Dice/Slots program (your existing one)
if (!process.env.PROGRAM_ID) throw new Error("PROGRAM_ID missing in .env");
const PROGRAM_ID = new PublicKey(process.env.PROGRAM_ID);

// (Optional) Crash & Plinko program IDs are used by their WS modules;
// we expose them in /health/all for convenience if present:
const CRASH_PROGRAM_ID = process.env.CRASH_PROGRAM_ID || process.env.NEXT_PUBLIC_CRASH_PROGRAM_ID || "";
const PLINKO_PROGRAM_ID = process.env.PLINKO_PROGRAM_ID || process.env.NEXT_PUBLIC_PLINKO_PROGRAM_ID || "";

// Shared RPC connection for dice REST
const connection = new Connection(CLUSTER, "confirmed");

// ---- DB wiring ----
let db;
try { db = require("./db"); } catch { db = {}; }
global.db = db;

// ---- Anchor discriminator + arg encoders (dice) ----
function anchorDisc(globalSnakeName) {
  return crypto.createHash("sha256").update(`global:${globalSnakeName}`).digest().slice(0, 8);
}

// PlaceBetLockArgs { bet_amount:u64, bet_type:u8, target:u8, nonce:u64, expiry_unix:i64 }
function encodePlaceBetLockArgs({ betAmount, betType, target, nonce, expiryUnix }) {
  const disc = anchorDisc("place_bet_lock");
  const buf = Buffer.alloc(8 + 8 + 1 + 1 + 8 + 8);
  let o = 0;
  disc.copy(buf, o); o += 8;
  buf.writeBigUInt64LE(BigInt(betAmount), o); o += 8;
  buf.writeUInt8(betType & 0xff, o++);      // u8
  buf.writeUInt8(target & 0xff, o++);       // u8
  buf.writeBigUInt64LE(BigInt(nonce), o); o += 8;
  buf.writeBigInt64LE(BigInt(expiryUnix), o); o += 8;
  return buf;
}

// ResolveBetArgs { roll:u8, payout:u64, ed25519_instr_index:u8 }
function encodeResolveBetArgs({ roll, payout, ed25519InstrIndex }) {
  const disc = anchorDisc("resolve_bet");
  const buf = Buffer.alloc(8 + 1 + 8 + 1);
  let o = 0;
  disc.copy(buf, o); o += 8;
  buf.writeUInt8(roll & 0xff, o++);                 // u8
  buf.writeBigUInt64LE(BigInt(payout), o); o += 8;  // u64
  buf.writeUInt8(ed25519InstrIndex & 0xff, o++);    // u8
  return buf;
}

const SYSVAR_INSTRUCTIONS_PUBKEY = new PublicKey(
  "Sysvar1nstructions1111111111111111111111111"
);

function placeBetLockKeys({ player, vaultPda, pendingBetPda }) {
  return [
    { pubkey: player, isSigner: true, isWritable: true },
    { pubkey: vaultPda, isSigner: false, isWritable: true },
    { pubkey: pendingBetPda, isSigner: false, isWritable: true },
    { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
  ];
}
function resolveBetKeys({ player, vaultPda, adminPda, pendingBetPda }) {
  return [
    { pubkey: player, isSigner: false, isWritable: true },
    { pubkey: vaultPda, isSigner: false, isWritable: true },
    { pubkey: adminPda, isSigner: false, isWritable: false },
    { pubkey: pendingBetPda, isSigner: false, isWritable: true },
    { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
    { pubkey: SYSVAR_INSTRUCTIONS_PUBKEY, isSigner: false, isWritable: false },
  ];
}

// ---- Express app (dice REST unchanged) ----
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Basic health
app.get("/health", (_req, res) => {
  res.json({ ok: true, cluster: CLUSTER, programId: PROGRAM_ID.toBase58() });
});

// Multi health (dice/crash/plinko visibility)
app.get("/health/all", (_req, res) => {
  res.json({
    ok: true,
    cluster: CLUSTER,
    dice_program: PROGRAM_ID.toBase58(),
    crash_program: CRASH_PROGRAM_ID || null,
    plinko_program: PLINKO_PROGRAM_ID || null,
  });
});

// Rules passthrough
app.get("/rules", async (_req, res) => {
  try {
    let rules = { rtp_bps: 9900, min_bet_lamports: 50000, max_bet_lamports: 5000000000 };
    if (db.getRules) rules = await db.getRules();
    res.json({
      rtp: Number(rules.rtp_bps) / 100,
      minBetSol: Number(rules.min_bet_lamports) / 1e9,
      maxBetSol: Number(rules.max_bet_lamports) / 1e9,
    });
  } catch (e) {
    res.status(500).json({ error: String(e.message || e) });
  }
});

/**
 * STEP 1 — deposit/lock (DICE)
 * Returns a v0 tx with CU price+limit, then the place_bet_lock ix.
 */
app.post("/bets/deposit_prepare", async (req, res) => {
  try {
    const { player, betAmountLamports, betType, targetNumber } = req.body || {};
    if (!player) return res.status(400).json({ error: "player required" });
    if (betAmountLamports == null || betType == null || targetNumber == null) {
      return res.status(400).json({ error: "betAmountLamports, betType, targetNumber required" });
    }
    if (!["over", "under"].includes(betType)) {
      return res.status(400).json({ error: "betType must be 'over' or 'under'" });
    }

    const playerPk = new PublicKey(player);
    const betTypeNum = betType === "over" ? 1 : 0;

    // Optional DB rules
    let rtp_bps = 9900;
    let min_bet_lamports = 50000n;
    let max_bet_lamports = 5000000000n;
    if (db.getRules) {
      const rules = await db.getRules();
      rtp_bps = rules.rtp_bps || rtp_bps;
      min_bet_lamports = BigInt(rules.min_bet_lamports || min_bet_lamports);
      max_bet_lamports = BigInt(rules.max_bet_lamports || max_bet_lamports);
    }

    const betAmt = BigInt(betAmountLamports);
    if (betAmt < min_bet_lamports || betAmt > max_bet_lamports) {
      return res.status(400).json({ error: "Bet amount out of allowed range" });
    }
    if (targetNumber < 2 || targetNumber > 98) {
      return res.status(400).json({ error: "Target number must be between 2 and 98" });
    }

    const nonce = BigInt(Date.now());
    const expiryUnix = BigInt(Math.floor(Date.now() / 1000) + Number(process.env.NONCE_TTL_SECONDS || 300));

    const vaultPda = deriveVaultPda();
    const pendingBetSeed = Buffer.alloc(8); pendingBetSeed.writeBigUInt64LE(nonce);
    const pendingBetPda = PublicKey.findProgramAddressSync(
      [Buffer.from("bet"), playerPk.toBuffer(), pendingBetSeed],
      PROGRAM_ID
    )[0];

    // Anchor ix data
    const data = encodePlaceBetLockArgs({
      betAmount: betAmountLamports,
      betType: betTypeNum,
      target: targetNumber,
      nonce: Number(nonce),
      expiryUnix: Number(expiryUnix),
    });
    const keys = placeBetLockKeys({ player: playerPk, vaultPda, pendingBetPda });
    const programIx = { programId: PROGRAM_ID, keys, data };

    // Put CU ixs first
    const cuPriceIx = ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 1 });
    const cuLimitIx = ComputeBudgetProgram.setComputeUnitLimit({ units: 400_000 });

    const { blockhash } = await connection.getLatestBlockhash("confirmed");
    const msgV0 = new TransactionMessage({
      payerKey: playerPk,
      recentBlockhash: blockhash,
      instructions: [cuPriceIx, cuLimitIx, programIx],
    }).compileToV0Message();

    const vtx = new VersionedTransaction(msgV0);
    const txBase64 = Buffer.from(vtx.serialize()).toString("base64");

    // Optional persistence
    try {
      await db.recordBet?.({
        player: playerPk.toBase58(),
        amount: betAmountLamports,
        betType: betTypeNum,
        target: targetNumber,
        roll: 0,
        payout: 0,
        nonce: Number(nonce),
        expiry: Number(expiryUnix),
        signature_base58: "",
      });
    } catch (e) { console.error("DB record error:", e); }

    res.json({
      nonce: String(nonce),
      expiryUnix: Number(expiryUnix),
      transactionBase64: txBase64,
    });
  } catch (e) {
    console.error("deposit_prepare error:", e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

/**
 * STEP 2 — resolve (DICE)
 * Returns v0 tx with CU price+limit, ed25519 verify, then resolve_bet.
 */
app.post("/bets/resolve_prepare", async (req, res) => {
  try {
    const { player, nonce: nonceStr } = req.body || {};
    if (!player) return res.status(400).json({ error: "player required" });
    if (nonceStr == null) return res.status(400).json({ error: "nonce required" });

    const playerPk = new PublicKey(player);
    const vaultPda = deriveVaultPda();
    const adminPda = deriveAdminPda();

    // fetch bet context recorded at deposit time (amount/bet_type/target)
    const nonce = BigInt(nonceStr);
    const lastBet = db.getBetByNonce ? await db.getBetByNonce(Number(nonce)) : null;
    const amount = lastBet ? Number(lastBet.bet_amount_lamports) : null;
    const betTypeNum = lastBet ? Number(lastBet.bet_type) : null;
    const targetNumber = lastBet ? Number(lastBet.target) : null;
    if (amount == null || betTypeNum == null || targetNumber == null) {
      return res.status(400).json({ error: "Backend missing bet context for this nonce" });
    }

    // Load RTP
    let rtp_bps = 9900;
    if (db.getRules) {
      const rules = await db.getRules();
      rtp_bps = rules.rtp_bps || rtp_bps;
    }

    // RNG + payout
    const roll = roll1to100();
    const win_odds = betTypeNum === 0 ? targetNumber - 1 : 100 - targetNumber;
    if (win_odds < 1 || win_odds > 99) {
      return res.status(400).json({ error: "Invalid win odds based on target" });
    }
    const win = betTypeNum === 0 ? roll < targetNumber : roll > targetNumber;
    const payoutLamports = win
      ? Number((BigInt(amount) * BigInt(rtp_bps)) / (100n * BigInt(win_odds)))
      : 0;

    const expiryUnix = Math.floor(Date.now() / 1000) + Number(process.env.NONCE_TTL_SECONDS || 300);

    // canonical message to be verified on-chain via ed25519 pre-instruction
    const msg = buildMessageBytes({
      programId: PROGRAM_ID.toBuffer(),
      vault: vaultPda.toBuffer(),
      player: playerPk.toBuffer(),
      betAmount: amount,
      betType: betTypeNum,
      target: targetNumber,
      roll,
      payout: payoutLamports,
      nonce: Number(nonce),
      expiryUnix: Number(expiryUnix),
    });

    const signature = await signMessageEd25519(msg);

    // ed25519 verify ix
    const edIx = buildEd25519VerifyIx({ message: msg, signature, publicKey: ADMIN_PK });
    const edIndex = 2; // CU price=0, CU limit=1, ed25519=2, resolve=3

    // build resolve_bet ix
    const pendingBetSeed = Buffer.alloc(8); pendingBetSeed.writeBigUInt64LE(nonce);
    const pendingBetPda = PublicKey.findProgramAddressSync(
      [Buffer.from("bet"), playerPk.toBuffer(), pendingBetSeed],
      PROGRAM_ID
    )[0];

    const data = encodeResolveBetArgs({ roll, payout: payoutLamports, ed25519InstrIndex: edIndex });
    const keys = resolveBetKeys({ player: playerPk, vaultPda, adminPda, pendingBetPda });
    const programIx = { programId: PROGRAM_ID, keys, data };

    // CU ixs at the front
    const cuPriceIx = ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 1 });
    const cuLimitIx = ComputeBudgetProgram.setComputeUnitLimit({ units: 400_000 });

    const { blockhash } = await connection.getLatestBlockhash("confirmed");
    const msgV0 = new TransactionMessage({
      payerKey: playerPk,
      recentBlockhash: blockhash,
      instructions: [cuPriceIx, cuLimitIx, edIx, programIx],
    }).compileToV0Message();

    const vtx = new VersionedTransaction(msgV0);
    const txBase64 = Buffer.from(vtx.serialize()).toString("base64");

    // optional DB update
    try {
      await db.updateBetPrepared?.({
        nonce: Number(nonce),
        roll,
        payout: payoutLamports,
      });
    } catch (e) { console.error("DB update error:", e); }

    res.json({
      roll,
      win,
      payoutLamports: String(payoutLamports),
      nonce: String(nonce),
      expiryUnix: Number(expiryUnix),
      transactionBase64: txBase64,
    });
  } catch (e) {
    console.error("resolve_prepare error:", e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

// ---- HTTP server + Socket.IO ----
const PORT = Number(process.env.PORT || 4000);
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// Slots WS (uses your dice program rails)
// ---- Slots WS ----
try {
  const slotsPath = require.resolve(__dirname + "/slots_ws.js");
  const slots = require(slotsPath);
  slots.attachSlots(io);
  console.log("Slots WS mounted from", slotsPath);
} catch (e) {
  console.error("slots_ws not found / failed to mount:", e);
}


// Crash WS (separate crash program, uses CRASH_PROGRAM_ID internally)
try {
  require("./crash_ws").attachCrash(io);
  console.log("Crash WS mounted");
} catch (e) {
  console.warn("crash_ws not found / failed to mount:", e?.message || e);
}


// Dashboard stats
// server.js
// Dashboard stats
app.get("/admin/stats", async (_req, res) => {
  try {
    const totalUsers = await db.getTotalUsers?.();
    const activeGames = await db.getActiveGames?.();
    const totalVolume = await db.getTotalVolume?.();
    const dailyRevenue = await db.getDailyRevenue?.();
    const recentActivity = await db.getRecentActivity?.(5);

    res.json({
      stats: {
        totalUsers,
        activeGames,
        totalVolume,
        dailyRevenue,
      },
      recentActivity,
    });
  } catch (e) {
    console.error("Admin stats error:", e);
    res.status(500).json({ error: e.message });
  }
});


// Plinko WS (separate plinko program, uses PLINKO_PROGRAM_ID internally)
try {
  require("./plinko_ws").attachPlinko(io);
  console.log("Plinko WS mounted");
} catch (e) {
  console.warn("plinko_ws not found / failed to mount:", e?.message || e);
}


// -------------------------------
// Transactions API
// -------------------------------
app.get("/admin/transactions", async (req, res) => {
  try {
    let { page = 1, limit = 20, type, status, game, search } = req.query;
    page = Number(page);
    limit = Number(limit);
    const offset = (page - 1) * limit;

    let whereClauses = [];
    let values = [];
    let idx = 1;

    if (type) {
      whereClauses.push(`bet_type = $${idx++}`);
      values.push(type);
    }
    if (status) {
      whereClauses.push(`status = $${idx++}`);
      values.push(status);
    }
    if (game) {
      whereClauses.push(`game = $${idx++}`);
      values.push(game);
    }
    if (search) {
      whereClauses.push(`player ILIKE $${idx++}`);
      values.push(`%${search}%`);
    }

    const whereSQL = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";

    // Fetch paginated rows
    const query = `
      SELECT id, player, bet_type, bet_amount_lamports, payout_lamports, status, created_at
      FROM bets
      ${whereSQL}
      ORDER BY created_at DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `;
    values.push(limit, offset);

    const { rows } = await db.pool.query(query, values);

    // Total count
    const countQuery = `SELECT COUNT(*) FROM bets ${whereSQL}`;
    const { rows: countRows } = await db.pool.query(countQuery, values.slice(0, -2));

    res.json({
      transactions: rows.map((r) => ({
        id: r.id,
        username: r.player,
        type: r.bet_type || "bet",
        game: r.game || null,
        amount: Number(r.bet_amount_lamports) / 1e9,
        currency: "SOL",
        status: r.status,
        timestamp: r.created_at,
        payout: Number(r.payout_lamports) / 1e9,
      })),
      total: Number(countRows[0].count),
      pages: Math.ceil(Number(countRows[0].count) / limit),
    });
  } catch (err) {
    console.error("Fetch transactions error:", err);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});

// Stats endpoint
app.get("/admin/transaction-stats", async (req, res) => {
  try {
    const { rows: vol } = await db.pool.query(
      `SELECT COALESCE(SUM(bet_amount_lamports),0) AS total FROM bets`
    );
    const { rows: daily } = await db.pool.query(
      `SELECT COALESCE(SUM(bet_amount_lamports),0) AS total FROM bets WHERE created_at > now() - interval '1 day'`
    );
    const { rows: weekly } = await db.pool.query(
      `SELECT COALESCE(SUM(bet_amount_lamports),0) AS total FROM bets WHERE created_at > now() - interval '7 days'`
    );
    const { rows: pending } = await db.pool.query(
      `SELECT COUNT(*) AS total FROM bets WHERE status = 'pending'`
    );

    res.json({
      totalVolume: Number(vol[0].total) / 1e9,
      dailyVolume: Number(daily[0].total) / 1e9,
      weeklyVolume: Number(weekly[0].total) / 1e9,
      pendingTransactions: Number(pending[0].total),
    });
  } catch (err) {
    console.error("Transaction stats error:", err);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

server.listen(PORT, () => {
  console.log(
    `api up on :${PORT} (cluster=${CLUSTER}, dice_program=${PROGRAM_ID.toBase58()}, crash_program=${CRASH_PROGRAM_ID || "—"}, plinko_program=${PLINKO_PROGRAM_ID || "—"})`
  );
});
